#ifndef GODOT_RUNTIME_API_H
#define GODOT_RUNTIME_API_H

#include <libgodot/gdextension_interface.h>

#ifdef __cplusplus
extern "C" {
#endif

#define LIBGODOT_API __attribute__((__visibility__("default")))

#define GODOT_OK 0
#define GODOT_ERROR -1
#define GODOT_EXIT 1

typedef void(*godot_register_extension_library_func)(const char*, GDExtensionInitializationFunction);
typedef int(*godot_load_engine_func)(int, char**);
typedef int(*godot_start_engine_func)(uint64_t);
typedef int(*godot_iterate_engine_func)();
typedef int(*godot_shutdown_engine_func)();

typedef struct {
    godot_register_extension_library_func godot_register_extension_library;
    godot_load_engine_func godot_load_engine;
    godot_start_engine_func godot_start_engine;
    godot_iterate_engine_func godot_iterate_engine;
    godot_shutdown_engine_func godot_shutdown_engine;
} GodotRuntimeAPI;

typedef GodotRuntimeAPI*(*godot_load_library_func)();

LIBGODOT_API GodotRuntimeAPI* godot_load_library();

#ifdef __cplusplus
}
#endif

#endif
